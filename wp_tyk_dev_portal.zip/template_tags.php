<?php

/**
 * Get the developer dashboard page
 * Prints directly to output
 * 
 * @return void
 */
function tyk_dev_portal_dashboard() {
	include_once TYK_DEV_PORTAL_PLUGIN_PATH . '/templates/api_subscribe_form.php';
}
